package com.example.ipose;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class WriteFile {
    Gson gson = new GsonBuilder().setPrettyPrinting().create();
    public void addText(ArrayList<User> users, String username, String password) throws IOException {
        try (FileWriter writer = new FileWriter("src/main/resources/data.json")) {
            users.add(new User(username, password));

            gson.toJson(users, writer);

        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
}
