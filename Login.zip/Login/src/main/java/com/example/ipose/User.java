package com.example.ipose;

public class User {
    public String username;
    public String password;
    public int highscore = 0;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    @Override
    public String toString() {
        return String.format("username: %s\npassword: %s\nhighscore: %s\n", this.username, this.password, this.highscore);
    }
}
