package com.example.ipose;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import java.io.IOException;

public class LoginApp extends Application {
    @Override
    public void start(Stage primaryStage) {
        ReadFile reader = new ReadFile();
        WriteFile writer = new WriteFile();

        primaryStage.setTitle("Log in");

        GridPane root = new GridPane();
        root.setHgap(10);
        root.setVgap(5);
        root.setAlignment(Pos.CENTER);

        ColumnConstraints col1 = new ColumnConstraints();
        col1.setMinWidth(125);
        root.getColumnConstraints().add(col1);

        Label loginText = new Label("Log in");
        loginText.setFont(new Font("Arial", 17.5));

        Label userText = new Label("Username: ");
        TextField userInput = new TextField();

        Label passwordText = new Label("Password: ");
        TextField passwordInput = new TextField();

        Button cancelButton = new Button("Cancel");
        Button submitButton = new Button("Submit");

        cancelButton.addEventHandler(MouseEvent.MOUSE_CLICKED,
                new EventHandler<>()  {
                    @Override
                    public void handle(MouseEvent e) {
                        try {
                            Platform.exit();
                        } catch (Exception ex) {
                            throw new RuntimeException(ex);
                        }
                    }
                });

        submitButton.addEventHandler(MouseEvent.MOUSE_CLICKED,
                new EventHandler<>() {
                    @Override
                    public void handle(MouseEvent e) {
                        try {
                            String username = userInput.getText();
                            String password = passwordInput.getText();

                            if (reader.checkUsers(username, password, loginText)) {
                                writer.addText(reader.readFile(), username, password);
                                Platform.exit();
                            } else {
                                userInput.setText("");
                                passwordInput.setText("");
                            }

                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                    }
                }) ;

        root.add(loginText, 0, 0);
        root.add(userText, 0, 1);
        root.add(userInput, 1, 1);
        root.add(passwordText, 0, 2);
        root.add(passwordInput, 1, 2);
        root.add(cancelButton, 0, 3);
        root.add(submitButton, 1, 3);

        Scene scene = new Scene(root, 350, 200);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}